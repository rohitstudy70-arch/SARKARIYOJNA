import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: 'v1.0.0',
    service: 'All Sarkari Yojana API'
  });
}
