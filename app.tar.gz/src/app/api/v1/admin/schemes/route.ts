import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const schemes = await prisma.scheme.findMany({
      orderBy: { createdAt: 'desc' }
    });
    return NextResponse.json(schemes);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch schemes' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const data = await req.json();
    
    // Generate slug from title
    const slug = data.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
    
    const scheme = await prisma.scheme.create({
      data: {
        ...data,
        slug
      }
    });
    return NextResponse.json(scheme);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create scheme' }, { status: 500 });
  }
}
