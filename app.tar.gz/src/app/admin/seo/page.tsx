export default function SeoPage() {
  return (
    <div className="max-w-4xl">
      <h2 className="text-2xl font-bold mb-6">SEO & Redirect Manager</h2>
      <div className="bg-white p-6 rounded shadow space-y-6">
        <div>
          <h3 className="text-lg font-semibold border-b pb-2 mb-4">URL Redirects (301)</h3>
          <p className="text-sm text-gray-500 mb-4">Map old legacy .html URLs to new clean routes.</p>
          <div className="flex gap-4 mb-4">
            <input type="text" className="flex-1 border rounded p-2" placeholder="Source URL (e.g. /pm-kisan.html)" />
            <input type="text" className="flex-1 border rounded p-2" placeholder="Destination URL (e.g. /pm-kisan)" />
            <button className="bg-primary text-white px-4 py-2 rounded font-semibold hover:bg-blue-800">Add</button>
          </div>
          <table className="w-full text-left border-collapse mt-4">
            <thead>
              <tr className="bg-gray-50 border-b">
                <th className="p-2 text-sm text-gray-600">Source</th>
                <th className="p-2 text-sm text-gray-600">Destination</th>
                <th className="p-2 text-sm text-gray-600">Type</th>
                <th className="p-2 text-sm text-gray-600">Action</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b">
                <td className="p-2 text-sm">/pm-awas-yojana.html</td>
                <td className="p-2 text-sm text-blue-600">/pm-awas-yojana</td>
                <td className="p-2 text-sm">301 Permanent</td>
                <td className="p-2 text-sm text-red-500 cursor-pointer">Remove</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
