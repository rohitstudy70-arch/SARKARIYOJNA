export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="flex h-screen bg-slate-100">
      <aside className="w-64 bg-primary text-white flex flex-col hidden md:flex">
        <div className="p-6 font-bold text-xl border-b border-white/10">
          Admin Portal
        </div>
        <nav className="flex-1 p-4 space-y-2">
          <a href="/admin" className="block px-4 py-2 rounded bg-white/10">Dashboard</a>
          <a href="/admin/schemes" className="block px-4 py-2 rounded hover:bg-white/5 transition">Content</a>
          <a href="/admin/settings" className="block px-4 py-2 rounded hover:bg-white/5 transition">Settings</a>
          <a href="/admin/seo" className="block px-4 py-2 rounded hover:bg-white/5 transition">SEO</a>
          <a href="/admin/media" className="block px-4 py-2 rounded hover:bg-white/5 transition">Media</a>
        </nav>
      </aside>
      <main className="flex-1 overflow-auto">
        <header className="bg-white shadow px-6 py-4 flex justify-between items-center">
          <h1 className="font-semibold text-gray-800">Control Panel</h1>
          <button className="text-sm text-gray-500 hover:text-gray-700">Logout</button>
        </header>
        <div className="p-6">
          {children}
        </div>
      </main>
    </div>
  )
}
