export default function SettingsPage() {
  return (
    <div className="max-w-4xl">
      <h2 className="text-2xl font-bold mb-6">Global Settings</h2>
      <div className="bg-white p-6 rounded shadow space-y-6">
        <div>
          <h3 className="text-lg font-semibold border-b pb-2 mb-4">Branding</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-gray-600 mb-1">Site Name</label>
              <input type="text" className="w-full border rounded p-2" defaultValue="All Sarkari Yojana" />
            </div>
            <div>
              <label className="block text-sm text-gray-600 mb-1">Admin Email</label>
              <input type="email" className="w-full border rounded p-2" defaultValue="contact@sarkariyojana.app" />
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-semibold border-b pb-2 mb-4">SMTP Configuration</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-gray-600 mb-1">Host</label>
              <input type="text" className="w-full border rounded p-2" placeholder="smtp.hostinger.com" />
            </div>
            <div>
              <label className="block text-sm text-gray-600 mb-1">Port</label>
              <input type="text" className="w-full border rounded p-2" placeholder="465" />
            </div>
          </div>
        </div>

        <div>
          <button className="bg-primary text-white px-6 py-2 rounded font-semibold hover:bg-blue-800 transition">Save Settings</button>
        </div>
      </div>
    </div>
  )
}
