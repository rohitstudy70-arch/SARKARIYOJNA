export default function CreateSchemePage() {
  return (
    <div className="max-w-5xl">
      <h2 className="text-2xl font-bold mb-6">Create New Scheme</h2>
      <form className="bg-white p-6 rounded shadow space-y-6">
        <div className="grid grid-cols-2 gap-6">
          <div>
            <label className="block text-sm text-gray-600 mb-1">Title (English)</label>
            <input type="text" className="w-full border rounded p-2" placeholder="e.g. PM Awas Yojana" />
          </div>
          <div>
            <label className="block text-sm text-gray-600 mb-1">Title (Hindi)</label>
            <input type="text" className="w-full border rounded p-2" placeholder="e.g. प्रधानमंत्री आवास योजना" />
          </div>
        </div>
        
        <div>
          <label className="block text-sm text-gray-600 mb-1">Short Description</label>
          <textarea className="w-full border rounded p-2 h-24" placeholder="Brief summary for cards..."></textarea>
        </div>

        <div>
          <label className="block text-sm text-gray-600 mb-1">Objective (Rich Text)</label>
          <div className="border rounded p-4 h-48 bg-gray-50 text-gray-400 flex items-center justify-center">
            [Rich Text Editor Component Placeholder]
          </div>
        </div>

        <div>
          <button type="button" className="bg-primary text-white px-6 py-2 rounded font-semibold hover:bg-blue-800 transition">Publish Scheme</button>
        </div>
      </form>
    </div>
  )
}
