export default function SchemesPage() {
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Content: Schemes</h2>
        <a href="/admin/schemes/create" className="bg-primary text-white px-4 py-2 rounded font-medium">+ Add Scheme</a>
      </div>
      <div className="bg-white rounded shadow overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-gray-50 border-b">
              <th className="p-4 font-semibold text-gray-600">Scheme Name</th>
              <th className="p-4 font-semibold text-gray-600">Status</th>
              <th className="p-4 font-semibold text-gray-600">Last Updated</th>
              <th className="p-4 font-semibold text-gray-600">Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b">
              <td className="p-4">PM Awas Yojana</td>
              <td className="p-4"><span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">PUBLISHED</span></td>
              <td className="p-4 text-gray-500">2026-07-12</td>
              <td className="p-4"><button className="text-blue-600 hover:underline">Edit</button></td>
            </tr>
            <tr className="border-b">
              <td className="p-4">PM Kisan Samman Nidhi</td>
              <td className="p-4"><span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">PUBLISHED</span></td>
              <td className="p-4 text-gray-500">2026-07-12</td>
              <td className="p-4"><button className="text-blue-600 hover:underline">Edit</button></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  )
}
