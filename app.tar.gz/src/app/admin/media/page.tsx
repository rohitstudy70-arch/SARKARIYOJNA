export default function MediaPage() {
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Media Library</h2>
        <button className="bg-primary text-white px-4 py-2 rounded font-medium">Upload File</button>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        <div className="bg-white p-4 rounded shadow flex flex-col items-center">
          <div className="w-full h-32 bg-gray-200 rounded flex items-center justify-center mb-2">
            <span className="text-gray-400">logo.png</span>
          </div>
          <p className="text-sm font-semibold truncate w-full text-center">logo.png</p>
          <p className="text-xs text-gray-500">1.0 MB</p>
        </div>
        <div className="bg-white p-4 rounded shadow flex flex-col items-center">
          <div className="w-full h-32 bg-gray-200 rounded flex items-center justify-center mb-2">
            <span className="text-gray-400">app-icon.png</span>
          </div>
          <p className="text-sm font-semibold truncate w-full text-center">app-icon.png</p>
          <p className="text-xs text-gray-500">348 KB</p>
        </div>
      </div>
    </div>
  )
}
