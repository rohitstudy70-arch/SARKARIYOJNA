export default function SimpleAdminDashboard() {
  const modules = [
    { title: 'Schemes', link: '/admin/schemes', count: 211 },
    { title: 'Jobs', link: '/admin/jobs', count: 0 },
    { title: 'Results', link: '/admin/results', count: 0 },
    { title: 'Admit Cards', link: '/admin/admit-cards', count: 0 },
    { title: 'Scholarships', link: '/admin/scholarships', count: 0 },
    { title: 'News', link: '/admin/news', count: 0 },
    { title: 'Blogs', link: '/admin/blogs', count: 0 },
    { title: 'Settings', link: '/admin/settings', count: 'Config' },
  ];

  return (
    <div className="max-w-6xl mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8 text-gray-800">Sarkari Yojana CMS</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {modules.map((mod) => (
          <a key={mod.title} href={mod.link} className="block bg-white p-6 rounded-lg shadow hover:shadow-md transition border-l-4 border-blue-600">
            <h2 className="text-xl font-semibold text-gray-700">{mod.title}</h2>
            <p className="text-2xl font-bold text-gray-900 mt-2">{mod.count}</p>
          </a>
        ))}
      </div>
    </div>
  );
}
