export default function Page() {
  return null; // The root '/' is intercepted by next.config.mjs to serve public/index.html
}
