/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  async rewrites() {
    return {
      beforeFiles: [
        // Serve the static index.html when the root is requested
        {
          source: '/',
          destination: '/index.html',
        },
      ],
    };
  },
};

export default nextConfig;
